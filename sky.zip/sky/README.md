Sky dataset, a collection of 60 images with groundtruth for sky segmentation.

This dataset was based on the Caltech Airplanes Side dataset by R. Fergus 15/02/03 (http://www.robots.ox.ac.uk/~vgg/data3.html). Images with sky presence from that dataset was selected and a groundtruth was created for it. The original names were keeped.

Eduardo B. Alexandre - 08/12/2016
